import dist.DiscreteDependencyTree;
import dist.DiscreteUniformDistribution;
import dist.Distribution;
import opt.*;
import opt.example.FourPeaksEvaluationFunction;
import opt.ga.*;
import opt.prob.GenericProbabilisticOptimizationProblem;
import opt.prob.MIMIC;
import opt.prob.ProbabilisticOptimizationProblem;
import shared.FixedIterationTrainer;

import java.util.Arrays;

/**
 * Copied from ContinuousPeaksTest
 * @version 1.0
 */
public class FourPeaksTest {
    /** The n value */
    private static final int N = 200;
    /** The t value */
    private static final int T = N / 5;
    
    public static void main(String[] args) {
        int[] iterations = {5, 10, 25, 50, 100, 250, 500, 750, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 250000};
        int[] ranges = new int[N];
        Arrays.fill(ranges, 2);
        EvaluationFunction ef = new FourPeaksEvaluationFunction(T);
        Distribution odd = new DiscreteUniformDistribution(ranges);
        HillClimbingProblem hcp = new GenericHillClimbingProblem(ef, odd, new DiscreteChangeOneNeighbor(ranges));
        GeneticAlgorithmProblem gap = new GenericGeneticAlgorithmProblem(ef, odd, new DiscreteChangeOneMutation(ranges), new SingleCrossOver());
        ProbabilisticOptimizationProblem pop = new GenericProbabilisticOptimizationProblem(ef, odd, new DiscreteDependencyTree(.1, ranges));

        for (int iterator : iterations) {
            System.out.println("============================");
            System.out.println("============================");
            System.out.println("Iteration " + iterator + ": ");
            rhc(ef, hcp, iterator);
            sa(ef, hcp, iterator);
            sga(ef, gap, iterator);
            mimic(ef, pop, iterator);
        }
    }

    private static void rhc(EvaluationFunction ef, HillClimbingProblem hcp, int iterations) {
        long starttime = System.currentTimeMillis();
        RandomizedHillClimbing rhc = new RandomizedHillClimbing(hcp);
        FixedIterationTrainer fit = new FixedIterationTrainer(rhc, iterations);
        fit.train();
        System.out.println("RHC: " + ef.value(rhc.getOptimal()));
        System.out.println("Time : "+ (System.currentTimeMillis() - starttime));

        System.out.println("============================");
    }

    private static void mimic(EvaluationFunction ef, ProbabilisticOptimizationProblem pop, int iterations) {
        long starttime;
        FixedIterationTrainer fit;
        starttime = System.currentTimeMillis();
        MIMIC mimic = new MIMIC(200, 100, pop);
        fit = new FixedIterationTrainer(mimic, iterations);
        fit.train();
        System.out.println("MIMIC: " + ef.value(mimic.getOptimal()));
        System.out.println("Time : "+ (System.currentTimeMillis() - starttime));
        System.out.println("============================");
    }

    private static void sga(EvaluationFunction ef, GeneticAlgorithmProblem gap, int iterations) {
        long starttime;
        FixedIterationTrainer fit;
        starttime = System.currentTimeMillis();
        StandardGeneticAlgorithm ga = new StandardGeneticAlgorithm(200, 10, 60, gap);
        fit = new FixedIterationTrainer(ga, iterations);
        fit.train();
        System.out.println("GA: " + ef.value(ga.getOptimal()));
        System.out.println("Time : "+ (System.currentTimeMillis() - starttime));

        System.out.println("============================");
    }

    private static void sa(EvaluationFunction ef, HillClimbingProblem hcp, int iterations) {
        long starttime;
        FixedIterationTrainer fit;
        starttime = System.currentTimeMillis();
        SimulatedAnnealing sa = new SimulatedAnnealing(1E12, .1, hcp);
        fit = new FixedIterationTrainer(sa, iterations);
        fit.train();
        System.out.println("SA: " + ef.value(sa.getOptimal()));
        System.out.println("Time : "+ (System.currentTimeMillis() - starttime));

        System.out.println("============================");
    }
}
